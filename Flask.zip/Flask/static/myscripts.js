function analyzeSentiment() {
  var result = document.getElementById("result").innerText; // Get the result content
  var newWindow = window.open("", "_blank");
  newWindow.document.write("<html><head><title>Sentiment Analysis Result</title></head><body><h2>Analysis Result</h2><p>" + result + "</p></body></html>");
}